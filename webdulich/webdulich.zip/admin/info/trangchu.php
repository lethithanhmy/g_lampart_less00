	<div class="shell">	
		<!-- Message OK -->		
		<div class="msg msg-ok">
			<p><strong>Đăng nhập thành công!</strong></p>
		</div>
    </div>